# README #

This README would normally document whatever steps are necessary to get your application up and running.
steps:

1.create virtual env and install requiremts.txt file
2.python manange.py makemigrations
3.python manange.py migrate
4.python manange.py runserver
5.python manange.py createsuperuser
6.Login -using email_id and password of superuser

#important functionalities#
Employee Add,
Employee Edit,
Employee Delete,
Employee View,
Add Student,
Add marks
