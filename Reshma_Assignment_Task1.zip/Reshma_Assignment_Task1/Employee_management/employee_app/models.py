import uuid
from django.db import models
# Create your models here.

class Employees(models.Model):

    email = models.EmailField('Primary Email', unique=True)
    first_name = models.CharField(
        'First Name', max_length=250, blank=True, null=True)
    last_name = models.CharField(
        'Last Name', max_length=250, blank=True, null=True)
    employee_code = models.CharField('Employee Code',max_length=250, unique=True)
    dept_name = models.CharField(
        'Department Name', max_length=250, blank=True, null=True)


class Students(models.Model):

    student_id = models.CharField('Student Id',max_length=250, unique=True)
    first_name = models.CharField(
        'First Name', max_length=250, blank=True, null=True)
    last_name = models.CharField(
        'Last Name', max_length=250, blank=True, null=True)
    registration_number = models.CharField('Registration number',max_length=250, unique=True)

class Student(models.Model):

    student_id = models.UUIDField(primary_key = True, default = uuid.uuid4, editable = False)
    first_name = models.CharField(
        'First Name', max_length=250, blank=True, null=True)
    last_name = models.CharField(
        'Last Name', max_length=250, blank=True, null=True)
    registration_number = models.CharField('Registration number',max_length=250, unique=True)


