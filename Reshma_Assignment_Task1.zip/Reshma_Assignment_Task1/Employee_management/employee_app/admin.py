from django.contrib import admin
from employee_app.models import Employees, Student


# Register your models here.
admin.site.register(Employees)
admin.site.register(Student)


