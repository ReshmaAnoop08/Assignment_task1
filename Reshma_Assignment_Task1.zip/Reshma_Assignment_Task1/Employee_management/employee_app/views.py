from django.shortcuts import  render, redirect
from django.core.cache import cache
from .forms import NewUserForm
from django.contrib.auth import login, authenticate, logout 
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from .forms import NewEmployeeForm, EmployeesListForm, NewStudentForm
from .models import Employees,Student

def login_request(request):
    """
    function for login.
    """
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}.")
                return redirect("add-employee")
            else:
                messages.error(request,"Invalid username or password.")
        else:
            messages.error(request,"Invalid username or password.")
    form = AuthenticationForm()
    return render(request=request, template_name="login.html", context={"login_form":form})


def logout_request(request):
    """
    function for logout.
    """
    logout(request)
    messages.info(request, "You have successfully logged out.") 
    return redirect("login")

def add_employee(request):
    """
    added employee details.
    """
    message = ""
    if request.method == "POST":
        form = NewEmployeeForm(request.POST)
        if form.is_valid():
            employee = form.save()
            message = "Added employee successfully."
            return render (request=request, template_name="addemployee.html", context={"employee_form":form,"message":message})

        else:
            message = "Failed to adding employee."
    form = NewEmployeeForm()
    return render (request=request, template_name="addemployee.html", context={"employee_form":form,"message":message})


def employees_list(request):
    """
    displaying employees list.
    """
    if request.method == "POST":
        form = EmployeesListForm(request.POST)
        if form.is_valid():
           form = Employees.objects.all()
           return render (request=request, template_name="viewemployees.html", context={"employee_form":form})
    form = Employees.objects.all()
    return render (request=request, template_name="viewemployees.html", context={"employee_form":form})


def delete_employee(request,pk):
    """
    deleted particular employee.
    """
    employee = Employees.objects.get(pk=pk)
    employee.delete()
    form = Employees.objects.all()
    return render (request=request, template_name="viewemployees.html", context={"employee_form":form})

def edit_employee(request,pk):
    """
    edited an employee.
    """    
    if request.method == "POST":
        employee = Employees.objects.get(pk=pk)
        employee.first_name = request.POST['firstname']
        employee.last_name = request.POST['lastname']
        employee.email = request.POST['email']
        employee.employee_code = request.POST['employeecode']
        employee.dept_name = request.POST['dept_name']
        employee.save()       
        form = Employees.objects.all()
        return render (request=request, template_name="viewemployees.html", context={"employee_form":form})
    else:
        employee = Employees.objects.get(pk=pk)
        return render (request=request, template_name="editemployee.html", context={"employee_form":employee})

def add_student(request):
    """
    added a student details.
    """
    message = ""
    if request.method == "POST":
        form = NewStudentForm(request.POST)
        if form.is_valid():
            student = form.save()
            message = "Added student successfully."
            #set cache for student id.
            cache.set('student_id', student.student_id, 800)
            return redirect('add-marks')
        else:
            message = "Failed to adding student."
    form = NewStudentForm()
    return render (request=request, template_name="addstudent.html", context={"student_form":form,"message":message})

def add_marks(request):
    """
    added the student marks without passing student id in url-cache used.
    """
    #get cache data for student id using the key.
    student_id = cache.get('student_id')
    student_obj= Student.objects.get(student_id = student_id)
    return render(request=request, template_name="addmarks.html", context={"student_form":student_obj,"message":"message"})

